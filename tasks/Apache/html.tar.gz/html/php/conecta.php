<?php
	ini_set('error_reporting',E_ALL ^ E_NOTICE);
	ini_set('display_errors','on');

	$conn = mysqli_connect("192.168.8.124","dario","dario","dbmalaga") or die ("Error de conexion");

	
?>